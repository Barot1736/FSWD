import React from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/Sidebar.css';

function Sidebar() {
  return (
    <aside className="sidebar">
      <NavLink to="/">🏠 Dashboard</NavLink>
      <NavLink to="/scanner">🌿 Plant Scanner</NavLink>
      <NavLink to="/care-tips">🩺 Care Tips</NavLink>
      <NavLink to="/marketplace">🛒 Marketplace</NavLink>
      <NavLink to="/chatbot">🤖 Chatbot</NavLink>
      <NavLink to="/forum">👥 Forum</NavLink>
      <NavLink to="/weather">🌦️ Weather</NavLink>
      <NavLink to="/admin">🛠️ Admin</NavLink>
    </aside>
  );
}

export default Sidebar;