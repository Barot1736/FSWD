import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../App'; // Import from your Auth context
import '../styles/Navbar.css';

function Navbar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth(); // Get from context

  const handleLogout = async () => {
    try {
      await logout(); // Use the logout function from context
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
      // Consider using a toast notification instead of alert
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">🌿 Agri<span>Sathi</span></div>
      <div className="navbar-right">
        <span>
          {user?.name ? `नमस्ते, ${user.name} ` : 'नमस्ते, कृषक मित्र'}
        </span>
        <span>32°C ☀️ Ahmedabad</span>
        {!user ? (
          <button className="logout-btn" onClick={() => navigate('/login')}>
            Login
          </button>
        ) : (
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        )}
      </div>
    </nav>
  );
}

export default Navbar;