import React from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/Dashboard.css';

function Dashboard({ user }) {
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>नमस्ते, {user ? user.name : 'कृषक मित्र'}!</h2>
        <p>32°C, Ahmedabad ☀️</p>
      </div>

      <div className="quick-actions">
        <NavLink to="/scanner">🌿 Scan a Plant</NavLink>
        <NavLink to="/care-tips">🩺 Care Tips</NavLink>
        <NavLink to="/marketplace">🛒 Visit Marketplace</NavLink>
        <NavLink to="/chatbot">🤖 Ask the Bot</NavLink>
        <NavLink to="/language">🌐 Change Language</NavLink>
        <NavLink to="/notifications">🔔 View Notifications</NavLink>
      </div>
    </div>
  );
}

export default Dashboard;