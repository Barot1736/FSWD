import React, { useState } from 'react';
import '../styles/Marketplace.css';

function Marketplace() {
  const [products] = useState([
    {
      id: 1,
      name: 'Organic Compost',
      price: '₹250',
      seller: 'Farmer A',
      image: 'https://via.placeholder.com/150'
    },
    {
      id: 2,
      name: 'Garden Tools Set',
      price: '₹800',
      seller: 'Farmer B',
      image: 'https://via.placeholder.com/150'
    },
    {
      id: 3,
      name: 'Neem Fertilizer',
      price: '₹150',
      seller: 'Farmer C',
      image: 'https://via.placeholder.com/150'
    }
  ]);

  return (
    <div className="marketplace">
      <h2>🛒 Marketplace</h2>
      <div className="product-grid">
        {products.map(product => (
          <div className="product-card" key={product.id}>
            <img src={product.image} alt={product.name} />
            <h3>{product.name}</h3>
            <p>Price: {product.price}</p>
            <p>Seller: {product.seller}</p>
            <button>Contact Farmer</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Marketplace;