import React, { useState } from 'react';
import '../styles/CommunityForum.css';

function CommunityForum() {
  const [question, setQuestion] = useState('');
  const [posts, setPosts] = useState([
    {
      id: 1,
      question: 'How to prevent leaf spot in tomatoes?',
      answers: 5,
      upvotes: 12
    },
    {
      id: 2,
      question: 'Best compost for flowering plants?',
      answers: 3,
      upvotes: 8
    }
  ]);

  const submitQuestion = () => {
    if (question.trim() === '') return;
    const newPost = {
      id: posts.length + 1,
      question,
      answers: 0,
      upvotes: 0
    };
    setPosts([newPost, ...posts]);
    setQuestion('');
  };

  return (
    <div className="forum">
      <h2>👥 Community Forum</h2>
      <div className="ask-box">
        <input
          type="text"
          placeholder="Ask a farming question..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submitQuestion()}
        />
        <button onClick={submitQuestion}>Ask</button>
      </div>
      <div className="post-list">
        {posts.map(post => (
          <div key={post.id} className="post">
            <p>{post.question}</p>
            <span>👍 {post.upvotes} | 💬 {post.answers}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CommunityForum;