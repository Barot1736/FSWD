import React, { useState } from 'react';
import '../styles/AdminPanel.css';

function AdminPanel() {
  const [users] = useState(['User A', 'User B']);
  const [posts] = useState(['Post 1: How to grow Tulsi?', 'Post 2: Neem compost usage']);
  const [products] = useState(['Compost', 'Fertilizer']);
  const [flagged] = useState(['Post 2: Neem compost usage']);

  return (
    <div className="admin-panel">
      <h2>🛠️ Admin Panel</h2>
      <div className="admin-section">
        <h3>Users</h3>
        <ul>{users.map((user, i) => <li key={i}>{user}</li>)}</ul>
      </div>
      <div className="admin-section">
        <h3>Posts</h3>
        <ul>{posts.map((post, i) => <li key={i}>{post}</li>)}</ul>
      </div>
      <div className="admin-section">
        <h3>Products</h3>
        <ul>{products.map((item, i) => <li key={i}>{item}</li>)}</ul>
      </div>
      <div className="admin-section flagged">
        <h3>🚩 Flagged Posts</h3>
        <ul>{flagged.map((item, i) => <li key={i}>{item}</li>)}</ul>
      </div>
    </div>
  );
}

export default AdminPanel;