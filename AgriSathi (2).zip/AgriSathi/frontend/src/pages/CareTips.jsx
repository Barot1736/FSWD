import React, { useState, useEffect } from 'react';
import '../styles/CareTips.css';

function CareTips({ user }) {
  const [query, setQuery] = useState('');
  const [tips, setTips] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentTip, setCurrentTip] = useState({
    name: '',
    watering: '',
    sunlight: '',
    remedies: '',
    diseases: '',
  });

  useEffect(() => {
    fetchCareTips();
  }, []);

  const fetchCareTips = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/care-tips');
      const data = await response.json();
      setTips(data);
    } catch (error) {
      console.error('Error fetching care tips:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentTip({ ...currentTip, [name]: value });
  };

  const handleSubmit = async (e) => {
    
    e.preventDefault();
    try {
      if (currentTip._id) {
        // Update existing tip
        await fetch(`http://localhost:5000/api/care-tips/${currentTip._id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(currentTip),
          credentials: 'include',
        });
      } else {
        // Create new tip
        await fetch('http://localhost:5000/api/care-tips', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(currentTip),
          credentials: 'include',
        });
      }
      fetchCareTips();
      setIsEditing(false);
      setCurrentTip({
        name: '',
        watering: '',
        sunlight: '',
        remedies: '',
        diseases: '',
      });
    } catch (error) {
      console.error('Error saving tip:', error);
    }
  };

  const handleEdit = (tip) => {
    setCurrentTip(tip);
    setIsEditing(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this tip?')) {
      try {
        await fetch(`http://localhost:5000/api/care-tips/${id}`, {
          method: 'DELETE',
          credentials: 'include',
        });
        fetchCareTips();
      } catch (error) {
        console.error('Error deleting tip:', error);
      }
    }
  };

  const filteredTips = tips.filter(tip =>
    tip.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="care-tips">
      <h2>🩺 Plant Care Tips</h2>
      <input
        type="text"
        placeholder="Search by plant name"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      {user?.isAdmin && (
        <div className="admin-controls">
          <button 
            className="add-tip-btn"
            onClick={() => {
              setIsEditing(!isEditing);
              if (isEditing) {
                setCurrentTip({
                  name: '',
                  watering: '',
                  sunlight: '',
                  remedies: '',
                  diseases: '',
                });
              }
            }}
          >
            {isEditing ? 'Cancel' : 'Add New Tip'}
          </button>

          {isEditing && (
            <form onSubmit={handleSubmit} className="tip-form">
              <input
                type="text"
                name="name"
                placeholder="Plant Name"
                value={currentTip.name}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="watering"
                placeholder="Watering Instructions"
                value={currentTip.watering}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="sunlight"
                placeholder="Sunlight Requirements"
                value={currentTip.sunlight}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="remedies"
                placeholder="Common Remedies"
                value={currentTip.remedies}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="diseases"
                placeholder="Common Diseases"
                value={currentTip.diseases}
                onChange={handleInputChange}
                required
              />
              <button type="submit">
                {currentTip._id ? 'Update Tip' : 'Save Tip'}
              </button>
            </form>
          )}
        </div>
      )}

      <div className="tips-list">
        {filteredTips.map((tip) => (
          <div key={tip._id} className="tip-card">
            <h3>{tip.name}</h3>
            <p><strong>Watering:</strong> {tip.watering}</p>
            <p><strong>Sunlight:</strong> {tip.sunlight}</p>
            <p><strong>Remedies:</strong> {tip.remedies}</p>
            <p><strong>Diseases:</strong> {tip.diseases}</p>
            {user?.isAdmin && (
              <div className="tip-actions">
                <button onClick={() => handleEdit(tip)}>Edit</button>
                <button onClick={() => handleDelete(tip._id)}>Delete</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default CareTips;