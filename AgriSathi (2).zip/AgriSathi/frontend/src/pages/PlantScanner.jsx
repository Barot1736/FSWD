import React, { useState } from 'react';
import '../styles/PlantScanner.css';

function PlantScanner() {
  const [image, setImage] = useState(null);
  const [scanResult, setScanResult] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
      setScanResult({
        name: 'Tulsi',
        confidence: '92%',
        care: 'Water daily, partial sunlight.',
        disease: 'No disease detected.'
      });
    }
  };

  return (
    <div className="plant-scanner">
      <h2>📷 Plant Scanner</h2>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      {image && <img src={image} alt="Scanned Plant" className="preview-image" />}

      {scanResult && (
        <div className="scan-result">
          <h3>Plant: {scanResult.name}</h3>
          <p>Confidence: {scanResult.confidence}</p>
          <p>Care Instructions: {scanResult.care}</p>
          <p>Disease Warnings: {scanResult.disease}</p>
        </div>
      )}
    </div>
  );
}

export default PlantScanner;