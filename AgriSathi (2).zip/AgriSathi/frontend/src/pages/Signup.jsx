import React, { useState } from 'react';
import '../styles/Auth.css';

function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('http://localhost:5000/api/auth/signup', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (res.ok) {
        alert('Signup successful!');
        // Optionally redirect or update state
      } else {
        setError(data.message || 'Signup failed');
      }
    } catch (err) {
      setError('Network error');
    }
  };

  return (
    <div className="auth-container">
      <h2>📝 Signup</h2>
      <form className="auth-form" onSubmit={handleSubmit}>
        <input
          type="text" placeholder="Name" required value={name} onChange={e => setName(e.target.value)}
        />
        <input
          type="email" placeholder="Email" required value={email} onChange={e => setEmail(e.target.value)}
        />
        <input
          type="password" placeholder="Password" required value={password} onChange={e => setPassword(e.target.value)}
        />
        <button type="submit">Signup</button>
        {error && <div className="auth-error">{error}</div>}
        
        Alrady a user?<a href='/login'>Login</a>
      </form>
    </div>
  );
}

export default Signup;
