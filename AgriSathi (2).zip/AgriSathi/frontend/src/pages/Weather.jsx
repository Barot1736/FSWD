import React from 'react';
import '../styles/Weather.css';

function Weather() {
  const weatherData = {
    today: '32°C, Sunny',
    week: [
      { day: 'Mon', forecast: '☀️ 33°C' },
      { day: 'Tue', forecast: '🌤️ 30°C' },
      { day: 'Wed', forecast: '🌧️ 27°C' },
      { day: 'Thu', forecast: '⛅ 29°C' },
      { day: 'Fri', forecast: '☀️ 32°C' }
    ],
    suggestion: 'Don’t water today, chance of rain tomorrow.'
  };

  return (
    <div className="weather">
      <h2>🌦️ Weather Insights</h2>
      <div className="current-weather">
        <strong>Today:</strong> {weatherData.today}
      </div>
      <div className="weekly-forecast">
        {weatherData.week.map((day, index) => (
          <div key={index} className="day">
            <span>{day.day}</span>
            <span>{day.forecast}</span>
          </div>
        ))}
      </div>
      <div className="suggestion">
        💡 {weatherData.suggestion}
      </div>
    </div>
  );
}

export default Weather;
