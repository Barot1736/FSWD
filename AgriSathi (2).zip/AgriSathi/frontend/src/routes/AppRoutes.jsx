import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from '../pages/Dashboard';
import PlantScanner from '../pages/PlantScanner';
import CareTips from '../pages/CareTips';
import Marketplace from '../pages/Marketplace';
import Chatbot from '../pages/Chatbot';
import CommunityForum from '../pages/CommunityForum';
import Weather from '../pages/Weather';
import AdminPanel from '../pages/AdminPanel';
import Login from '../pages/Login';
import Signup from '../pages/Signup';

function AppRoutes({ setUser, user }) {
  return (
    <Routes>
      <Route path="/" element={<Dashboard user={user} />} />
      <Route path="/scanner" element={<PlantScanner user={user} />} />
      <Route path="/care-tips" element={<CareTips user={user} />} />
      <Route path="/marketplace" element={<Marketplace user={user} />} />
      <Route path="/chatbot" element={<Chatbot user={user} />} />
      <Route path="/forum" element={<CommunityForum user={user} />} />
      <Route path="/weather" element={<Weather user={user} />} />
      <Route path="/admin" element={<AdminPanel user={user} />} />
      <Route path="/login" element={<Login setUser={setUser} />} />
      <Route path="/signup" element={<Signup setUser={setUser} />} />
    </Routes>
  );
}

export default AppRoutes;