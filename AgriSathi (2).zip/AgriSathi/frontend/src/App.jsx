import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import AppRoutes from './routes/AppRoutes';
import Sidebar from './components/Sidebar';
import './styles/App.css';
import { createContext, useContext } from 'react'; // Add this

// Create Auth Context
export const AuthContext = createContext();

// Add this above App function
export function useAuth() {
  return useContext(AuthContext);
}

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkSession = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/auth/check-session', {
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          throw new Error('Session check failed');
        }

        const data = await response.json();
        if (data.loggedIn) {
          setUser(data.user);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Error checking session:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }

      if (data.loggedIn) {
      setUser({
        name: data.user.name,
        email: data.user.email,
        isAdmin: data.user.isAdmin
    });
}

      
    };

    checkSession();
  }, []);

  const logout = async () => {
    try {
      await fetch('http://localhost:5000/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (loading) {
    return (
      <div className="loading-screen">
        <div>🌱 Loading AgriSathi...</div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, setUser, logout }}>
      <div className="app">
        <Navbar />
        <div className="main-layout">
          <Sidebar />
          <div className="content">
            <AppRoutes setUser={setUser} user={user} />
          </div>
        </div>
      </div>
    </AuthContext.Provider>
  );
}

export default App;