const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/user');

const router = express.Router();




// Signup
router.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ message: 'Email already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashed });
    await user.save();

    req.session.userId = user._id;
    res.status(201).json({ message: 'Signup successful', user: { name, email } });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: 'Invalid credentials' });

    req.session.userId = user._id;
    res.json({
      message: 'Login successful',
      user: { name: user.name, email: user.email, isAdmin: user.isAdmin } // <-- Return isAdmin
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ message: 'Logout failed' });
    res.clearCookie('connect.sid');
    res.json({ message: 'Logout successful' });
  });
});

// Check session
// Add to auth.js
router.get('/check-session', async (req, res) => {
  if (req.session.userId) {
    const user = await User.findById(req.session.userId);
    if (user) {
      return res.json({
        loggedIn: true,
        user: { name: user.name, email: user.email, isAdmin: user.isAdmin }
      });
    }
  }
  res.json({ loggedIn: false });
});



module.exports = router;
