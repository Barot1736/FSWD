const express = require('express');
const router = express.Router();
const CareTip = require('../models/CareTip');

// Get all care tips
router.get('/', async (req, res) => {
  try {
    const tips = await CareTip.find();
    res.json(tips);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new care tip (admin only)
router.post('/', async (req, res) => {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  
  try {
    const newTip = new CareTip(req.body);
    await newTip.save();
    res.status(201).json(newTip);
  } catch (error) {
    res.status(400).json({ message: 'Invalid data' });
  }
});

// Update care tip (admin only)
router.put('/:id', async (req, res) => {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  
  try {
    const updatedTip = await CareTip.findByIdAndUpdate(
      req.params.id, 
      req.body, 
      { new: true }
    );
    res.json(updatedTip);
  } catch (error) {
    res.status(400).json({ message: 'Invalid data' });
  }
});

// Delete care tip (admin only)
router.delete('/:id', async (req, res) => {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  
  try {
    await CareTip.findByIdAndDelete(req.params.id);
    res.json({ message: 'Tip deleted' });
  } catch (error) {
    res.status(404).json({ message: 'Tip not found' });
  }
});

module.exports = router;