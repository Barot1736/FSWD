const mongoose = require('mongoose');

const careTipSchema = new mongoose.Schema({
  name: { type: String, required: true },
  watering: { type: String, required: true },
  sunlight: { type: String, required: true },
  remedies: { type: String, required: true },
  diseases: { type: String, required: true },
}, { timestamps: true });

module.exports = mongoose.model('CareTip', careTipSchema);